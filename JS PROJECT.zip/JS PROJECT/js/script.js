function delay() {
    setInterval(function(){ alert("3 min past"); }, 180000);
    getdate();
}
function displaydate(){
    var date = document.getElementById("date");
    var dt = new Date();
    date.innerHTML=dt.getDate()+"/"+(parseInt(dt.getMonth())+1)+"/"+dt.getFullYear()+" "+dt.getHours()+"-"+dt.getMinutes()+"-"+dt.getSeconds();
}
function getdate(){
    setInterval(displaydate,1000);
}
function labelchange(res){
 var label=document.getElementById(res);
 label.style.color="red";
}
function labelprevious(res){
    var label=document.getElementById(res);
    label.style.color="white";
    label.style.textShadow="1px 1px 2px blue,-1px 1px 2px blue,1px -1px 2px blue,-1px -1px 2px blue";
}

function validate(){
    var fname=document.getElementById("fname");
    var lname=document.getElementById("lname");
    var pass=document.getElementById("pass");
    var rpass=document.getElementById("rpass");
    var male = document.getElementById("male").checked;
    var female = document.getElementById("female").checked;
    var phno = document.getElementById("phno");
    var dob = document.getElementById("dob");
    var email = document.getElementById("email");
    if(pass.value!=""&&rpass.value!=""){
        if((pass.value!=rpass.value)){
            alert("incorrect password please enter correct password");
            rpass.value="";
            pass.value="";
            pass.focus();
            return;
        }
    }
    if(fname.value==""){
        alert("FirstName Should be Filled");
        fname.focus();
        return;
    }
    if(lname.value==""){
        alert("LastName Should be Filled");
        lname.focus();
        return;
    }
    if(pass.value==""){
        alert("Please enter password");
        pass.focus();
        return;
    }
    if(rpass.value==""){
        alert("Please enter password Again");
        rpass.focus();
        return;
    }
    if(male==false&&female==false){
        alert("Please select gender");
        return;
    }
    if(phno.value==""){
        alert("Please enter Mobile number");
        phno.focus();
        return;
    }
    if(dob.value==""){
        alert("Please enter Your Date of Birth");
        dob.focus();
        return;
    }
    if(email.value==""){
        alert("Please enter Your Email");
        email.focus();
        return;
    }
    if(/^[a-zA-Z]+$/.test(fname.value)==false){
        alert("FirstName Must Be a Character");
        fname.value="";
        fname.focus();
        return;
    }
    if(/^[a-zA-Z]+$/.test(lname.value)==false){
        alert("LastName Must Be a Character");
        lname.value="";
        lname.focus();
        return;
    }
    if(/^[a-zA-Z!@#$%^&*()]{6,20}$/.test(pass.value)==false){
        alert("password should be 6 to 20 characters long");
        pass.value="";
        rpass.value="";
        pass.focus();
        return;
    }
    if(/^[0-9]{3}[-. ][0-9]{3}[-. ][0-9]{4}$/.test(phno.value)==false){
        alert("Mobile number should be in the format (XXX-XXX-XXXX or XXX.XXX.XXXX or XXX XXX XXXX)");
        phno.value="";
        phno.focus();
        return;
    }

    if(/^[0-3][0-9][-][0-1][0-9][-][0-9][0-9][0-9][0-9]$/.test(dob.value)==false){
        alert("Your D.O.B should be in the format (DD-MM-YYYY)");
        dob.value="";
        dob.focus();
        return;
    }

    if(/^[a-z][a-z0-9_]+@[a-z]+[.][a-z][a-z.]+$/.test(email.value)==false){
        alert("Please Enter correct Email");
        email.value="";
        email.focus();
        return;
    }
    window.location.href="sucess.html";
}